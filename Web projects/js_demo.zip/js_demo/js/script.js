function Czech(){
    var p = prompt("Now tell me how many ways of saying hello informally were there?");
    if (p != null) {
        document.getElementById('question').innerHTML = "Wrong"
    }
}